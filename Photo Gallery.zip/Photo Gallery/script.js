// --- DOM Element References ---
// Main gallery elements
const galleryGrid = document.getElementById('galleryGrid'); // Now refers to .gallery-container
const themeToggle = document.getElementById('theme-toggle'); // Targets the checkbox inside the new theme toggle label

// Filter and Sort buttons
const filterButtons = document.querySelectorAll('.filter-btn'); // Filter buttons (always visible)
const toggleSortOptionsBtn = document.getElementById('burger-toggle'); // Targets the checkbox inside the burger icon
const sortOptionsContainer = document.getElementById('sortOptionsContainer'); // Container for sort buttons
const sortButtons = document.querySelectorAll('.sort-btn'); // Sort buttons

// Lightbox elements
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightbox-image'); // Corrected ID
const closeBtn = document.querySelector('.close-btn');
const prevBtn = document.getElementById('prev-button-ui');
const nextBtn = document.getElementById('next-button-ui');
const uploadTimeElement = document.getElementById('upload-time'); // Info element
const imageCategoryElement = document.getElementById('image-category'); // Info element
const magnifier = document.querySelector('.magnifier'); // Magnifier element

// Slideshow elements (now primarily controlled from modal)
const slideshowButtonHeader = document.getElementById('slideshow-button-header'); // The new slideshow button in the header
const slideshowProgressBar = document.querySelector('.slideshow-progress-bar'); // Progress bar

// Slideshow Selection Modal elements
const selectionModal = document.getElementById('selection-modal'); // Modal container
const closeModalBtn = document.querySelector('.close-modal'); // Modal close button
const imageSelectionContainer = document.querySelector('.image-selection-container'); // Checkbox grid container
const slideshowSpeedSelect = document.getElementById('slideshow-speed'); // Speed dropdown, now in modal
const startSelectedSlideshowBtn = document.getElementById('start-selected-slideshow-ui');
const cancelSlideshowSettingsBtn = document.getElementById('cancel-slideshow-settings-ui');

// Custom Message Box
const customMessageBox = document.getElementById('customMessageBox');


// --- Global Variables ---
// 'images' will now be populated by reading from the DOM
let images = []; // Array to hold all image data (master list, populated from HTML)
let filteredImages = []; // Array to hold currently filtered and sorted images for display (references to DOM elements)
let currentImageIndex = 0; // Index of the currently displayed image in the filteredImages array
let slideshowInterval = null; // Variable to hold the setInterval ID for slideshow
let isSlideshowPlaying = false; // Flag to track slideshow state
let slideshowSpeed = 3000; // Default slideshow speed (3 seconds)
let isZoomed = false; // Flag for image zoom state
let slideshowImages = []; // Array to hold images specifically selected by the user for the slideshow (references to DOM elements)


// --- Core Functions ---

/**
 * Initializes the gallery on page load.
 * Reads image data from HTML, sets up initial display, and attaches event listeners.
 */
function initGallery() {
    console.log('initGallery: Starting initialization.');

    // Read image data directly from HTML DOM elements
    const galleryItems = document.querySelectorAll('.gallery-item');
    images = Array.from(galleryItems).map((item, index) => {
        const imgSrc = item.dataset.src;
        const imgTitle = item.dataset.title;
        const imgCategory = item.dataset.category;
        const imgTimestamp = item.dataset.timestamp;
        
        // Assign a random size for demonstration purposes (between 500KB and 2.5MB)
        const imgSize = Math.floor(Math.random() * 2000) + 500;

        // Update the timestamp display in the HTML
        const timestampDisplay = item.querySelector('.timestamp-display');
        if (timestampDisplay) {
            timestampDisplay.textContent = calculateTimeAgo(imgTimestamp);
        }

        // Attach click listener directly to the gallery item
        // The click listener is now attached to the .gallery-item itself,
        // which is the "card" element.
        item.addEventListener('click', () => {
            console.log('Gallery item clicked:', imgSrc);
            openLightbox(imgSrc);
        });

        return {
            element: item, // Store a reference to the actual DOM element
            src: imgSrc,
            title: imgTitle,
            category: imgCategory,
            timestamp: imgTimestamp,
            size: imgSize,
            selectedForSlideshow: false // Default to false, user will select
        };
    });
    
    filteredImages = [...images]; // Initially, filtered images are all images

    console.log('initGallery: images length (from HTML):', images.length);
    console.log('initGallery: filteredImages length (initial):', filteredImages.length);

    // Set initial dark mode based on local storage
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode === 'true') {
        document.body.classList.add('dark-mode');
        themeToggle.checked = true; // Set checkbox to checked for dark mode
        console.log('initGallery: Dark mode enabled.');
    } else {
        themeToggle.checked = false; // Set checkbox to unchecked for light mode
        console.log('initGallery: Light mode enabled.');
    }

    // No need to call renderGallery here, as images are already in HTML
    // We just need to apply initial filter/sort (which is 'all' and 'date')
    setupEventListeners(); // Attach all event listeners
    
    // Set initial active filter button (All)
    const allFilterButton = document.querySelector('.filter-btn[data-filter="all"]');
    if (allFilterButton) {
        allFilterButton.classList.add('active');
        console.log('initGallery: "All" filter button set to active.');
    }

    // Apply default sort (by date) on load
    const defaultSortButton = document.querySelector('.sort-btn[data-sort="date"]');
    if (defaultSortButton) {
        defaultSortButton.classList.add('active');
        console.log('initGallery: Default sort "by Date" set to active.');
        applyCurrentSort(); // Sort the initial 'all' images by date
    }
    console.log('initGallery: Initialization complete.');
}

/**
 * Renders images into the gallery grid based on the provided array.
 * This function is now modified to hide/show and reorder existing DOM elements.
 * @param {Array} imagesToDisplay - The array of image objects (containing 'element' references) to display.
 */
function displayGalleryItems(imagesToDisplay) {
    console.log('displayGalleryItems: Called with', imagesToDisplay.length, 'images.');
    
    // First, hide all gallery items
    images.forEach(image => {
        image.element.style.display = 'none';
    });

    // Then, append and show only the images that should be displayed, in the correct order
    const fragment = document.createDocumentFragment();
    imagesToDisplay.forEach(image => {
        image.element.style.display = 'flex'; // Show the element (using flex for centering content)
        fragment.appendChild(image.element); // Append to fragment for efficient DOM update
    });
    galleryGrid.appendChild(fragment); // Append all at once
    console.log('displayGalleryItems: Gallery display updated.');
}


/**
 * Sets up all global event listeners for buttons, keyboard, etc.
 */
function setupEventListeners() {
    console.log('setupEventListeners: Attaching event listeners.');
    // Close lightbox button
    closeBtn.addEventListener('click', closeLightbox);
    
    // Lightbox navigation buttons
    prevBtn.addEventListener('click', showPrevImage);
    nextBtn.addEventListener('click', showNextImage);
    
    // Keyboard navigation for lightbox
    document.addEventListener('keydown', (e) => {
        if (lightbox.classList.contains('active')) { // Check if lightbox is currently active
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') showPrevImage();
            if (e.key === 'ArrowRight') showNextImage();
        }
    });
    
    // Sort Options Toggle Button (burger icon)
    // Listen to the 'change' event on the hidden checkbox inside the burger label
    toggleSortOptionsBtn.addEventListener('change', () => {
        sortOptionsContainer.classList.toggle('sort-options-visible');
        console.log('Sort options toggled.');
    });

    // Filter buttons (always visible)
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterButtons.forEach(btn => btn.classList.remove('active')); // Deactivate all
            button.classList.add('active'); // Activate clicked one
            filterImages(button.dataset.filter); // Apply filter
            console.log('Filter applied:', button.dataset.filter);
        });
    });
    
    // Sort buttons (within the toggled container)
    sortButtons.forEach(button => {
        button.addEventListener('click', function() {
            sortButtons.forEach(btn => btn.classList.remove('active')); // Deactivate all
            this.classList.add('active'); // Activate clicked one
            applyCurrentSort(); // Apply sort
            console.log('Sort applied:', this.dataset.sort);
            // Optionally close the sort options after a selection
            toggleSortOptionsBtn.checked = false; // Uncheck the burger checkbox
            sortOptionsContainer.classList.remove('sort-options-visible');
        });
    });
    
    // Theme toggle button (now a checkbox)
    themeToggle.addEventListener('change', toggleTheme); // Listen to 'change' event on the checkbox
    
    // --- NEW: Slideshow button in header ---
    slideshowButtonHeader.addEventListener('click', openSelectionModal);
    
    // Magnifier effect (mousemove on lightbox image)
    lightboxImage.addEventListener('mousemove', handleMagnifier);
    lightboxImage.addEventListener('mouseenter', () => {
        if (isZoomed) {
            magnifier.style.display = 'block'; // Show magnifier only if zoomed
            console.log('Magnifier shown.');
        }
    });
    lightboxImage.addEventListener('mouseleave', () => {
        magnifier.style.display = 'none'; // Hide magnifier on mouse leave
        console.log('Magnifier hidden.');
    });
    lightboxImage.addEventListener('click', toggleZoom); // Click on image to zoom/unzoom
    
    // Slideshow Selection Modal buttons
    closeModalBtn.addEventListener('click', closeSelectionModal); // Close modal
    cancelSlideshowSettingsBtn.addEventListener('click', closeSelectionModal); // Cancel button in modal
    startSelectedSlideshowBtn.addEventListener('click', startSelectedSlideshow); // Start slideshow from modal
    
    // Slideshow speed dropdown (now in modal, no direct listener here)
    // The event listener for slideshowSpeedSelect will be set up when the modal opens if needed,
    // or its value will be read when startSelectedSlideshow is called.
    console.log('setupEventListeners: All event listeners attached.');
}

/**
 * Applies the currently active sort order to the filtered images and re-renders the gallery.
 */
function applyCurrentSort() {
    console.log('applyCurrentSort: Applying current sort.');
    const activeSortButton = document.querySelector('.sort-btn.active');
    const sortBy = activeSortButton ? activeSortButton.dataset.sort : 'date'; // Default to 'date' if no active sort
    const sortedImages = sortImages(filteredImages, sortBy);
    displayGalleryItems(sortedImages); // Use displayGalleryItems for DOM manipulation
    console.log('applyCurrentSort: Sort applied by:', sortBy);
}

/**
 * Sorts an array of images based on a specified criterion.
 * @param {Array} images - The array of image objects to sort.
 * @param {string} sortBy - The sorting criterion ('date', 'alphabet', 'size').
 * @returns {Array} The sorted array of image objects.
 */
function sortImages(images, sortBy) {
    console.log('sortImages: Sorting by:', sortBy);
    const sortedImages = [...images]; // Create a shallow copy to avoid modifying original array
    
    switch(sortBy) {
        case 'date':
            // Sort by timestamp (most recent first)
            return sortedImages.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        case 'alphabet':
            // Sort by title alphabetically
            return sortedImages.sort((a, b) => a.title.localeCompare(b.title));
        case 'size':
            // Sort by mock size (largest first)
            return sortedImages.sort((a, b) => b.size - a.size);
        default:
            return sortedImages; // Return as is if no valid sort criterion
    }
}

/**
 * Filters the main image data by category and then applies the current sort.
 * @param {string} category - The category to filter by ('all', 'nature', 'animals', 'architecture', 'people').
 */
function filterImages(category) {
    console.log('filterImages: Filtering by category:', category);
    if (category === 'all') {
        filteredImages = [...images]; // Show all images from master list
    } else {
        filteredImages = images.filter(image => image.category === category); // Filter by category
    }
    
    applyCurrentSort(); // Apply the current sort to the newly filtered images
    console.log('filterImages: Filtered images count:', filteredImages.length);
}

/**
 * Opens the lightbox with the specified image.
 * @param {string} imageSrc - The source URL of the image to display.
 */
function openLightbox(imageSrc) {
    console.log('openLightbox: Attempting to open image with src:', imageSrc);
    // Find the image object in the 'images' array using its src
    const image = images.find(img => img.src === imageSrc);

    if (!image) {
        showMessageBox("Image not found in the gallery data.");
        console.error('openLightbox: Image not found for src:', imageSrc);
        return;
    }
    
    // Find the index of this image within the currently filtered/sorted view
    // This is crucial for prev/next navigation to work correctly within the current view
    currentImageIndex = filteredImages.findIndex(img => img.src === imageSrc);

    lightboxImage.src = image.src; // Set image source
    lightboxImage.alt = image.title; // Set alt text
    
    // Update image info in lightbox
    uploadTimeElement.textContent = `Uploaded: ${calculateTimeAgo(image.timestamp)}`;
    imageCategoryElement.textContent = `Category: ${image.category}`;
    
    lightbox.classList.add('active'); // Show lightbox by adding 'active' class
    document.body.style.overflow = 'hidden'; // Prevent background scrolling

    // Reset zoom state when opening a new image
    isZoomed = false;
    lightboxImage.classList.remove('zoomed');
    lightboxImage.style.cursor = 'zoom-in';
    magnifier.style.display = 'none';

    // Stop any active slideshow when manually opening lightbox
    stopSlideshow(); // Ensure slideshow is stopped if lightbox opened manually
    console.log('openLightbox: Lightbox opened for image:', image.title);
}

/**
 * Closes the lightbox.
 */
function closeLightbox() {
    console.log('closeLightbox: Closing lightbox.');
    lightbox.classList.remove('active'); // Hide lightbox by removing 'active' class
    document.body.style.overflow = 'auto'; // Restore background scrolling
    lightboxImage.classList.remove('zoomed'); // Ensure image is unzoomed
    stopSlideshow(); // Ensure slideshow is stopped
    console.log('closeLightbox: Lightbox closed.');
}

/**
 * Displays the next image in the lightbox based on the current `filteredImages` list.
 */
function showNextImage() {
    console.log('showNextImage: Navigating to next image.');
    // Determine the array to navigate (slideshowImages if playing, else filteredImages)
    const currentSet = isSlideshowPlaying && slideshowImages.length > 0 ? slideshowImages : filteredImages;
    
    if (currentSet.length === 0) {
        showMessageBox("No images to navigate.");
        console.warn('showNextImage: No images in current set to navigate.');
        return;
    }

    // Calculate next index, wrapping around if at the end
    currentImageIndex = (currentImageIndex + 1) % currentSet.length;
    
    // Get the image object from the current set
    const imageToDisplay = currentSet[currentImageIndex];
    
    // Open the lightbox using the image's src
    openLightbox(imageToDisplay.src);
    console.log('showNextImage: Displaying next image:', imageToDisplay.title);
}

/**
 * Displays the previous image in the lightbox based on the current `filteredImages` list.
 */
function showPrevImage() {
    console.log('showPrevImage: Navigating to previous image.');
    // Determine the array to navigate (slideshowImages if playing, else filteredImages)
    const currentSet = isSlideshowPlaying && slideshowImages.length > 0 ? slideshowImages : filteredImages;
    
    if (currentSet.length === 0) {
        showMessageBox("No images to navigate.");
        console.warn('showPrevImage: No images in current set to navigate.');
        return;
    }

    // Calculate previous index, wrapping around to the end if at the beginning
    currentImageIndex = (currentImageIndex - 1 + currentSet.length) % currentSet.length;
    
    // Get the image object from the current set
    const imageToDisplay = currentSet[currentImageIndex];
    
    // Open the lightbox using the image's src
    openLightbox(imageToDisplay.src);
    console.log('showPrevImage: Displaying previous image:', imageToDisplay.title);
}

/**
 * Toggles dark mode on/off and saves the preference to localStorage.
 */
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode); // Save preference
    console.log('toggleTheme: Dark mode is now:', isDarkMode);
    // The visual change (moon/sun icon) is handled purely by CSS based on `themeToggle.checked`
}

/**
 * Toggles the zoom level of the lightbox image.
 */
function toggleZoom() {
    isZoomed = !isZoomed; // Toggle zoom state
    
    if (isZoomed) {
        lightboxImage.classList.add('zoomed'); // Add 'zoomed' class for CSS scaling
        lightboxImage.style.cursor = 'zoom-out'; // Change cursor
        magnifier.style.display = 'block'; // Show magnifier
        console.log('toggleZoom: Image zoomed in.');
    } else {
        lightboxImage.classList.remove('zoomed'); // Remove 'zoomed' class
        lightboxImage.style.cursor = 'zoom-in'; // Change cursor
        magnifier.style.display = 'none'; // Hide magnifier
        console.log('toggleZoom: Image zoomed out.');
    }
}

/**
 * Displays a custom message box instead of `alert()`.
 * @param {string} message - The message to display.
 */
function showMessageBox(message) {
    customMessageBox.innerHTML = `
        <p>${message}</p>
        <button onclick="this.parentNode.style.display='none'">OK</button>
    `;
    customMessageBox.style.display = 'flex'; // Show the message box
    console.log('showMessageBox: Displayed message:', message);
}

// --- Slideshow Functionality ---

/**
 * Opens the slideshow selection modal, populating it with all gallery images.
 * All checkboxes are initially unchecked, requiring manual selection.
 */
function openSelectionModal() {
    console.log('openSelectionModal: Opening selection modal.');
    stopSlideshow(); // Ensure any running slideshow is stopped before opening modal
    imageSelectionContainer.innerHTML = ''; // Clear previous selections
    
    // Ensure all images in the master 'images' array are marked as not selected for slideshow initially
    images.forEach(img => {
        img.selectedForSlideshow = false;
    });

    // Populate the modal with ALL images from the 'images' (master) array
    images.forEach((image, index) => {
        const item = document.createElement('div');
        item.className = 'image-selection-item rounded-lg';
        
        item.innerHTML = `
            <label for="modal-img-${index}">
                <input type="checkbox" class="image-selection-checkbox" id="modal-img-${index}" data-index="${index}" ${image.selectedForSlideshow ? 'checked' : ''}>
                <img src="${image.src}" alt="${image.title}">
                <span>${image.title}</span>
            </label>
        `;
        imageSelectionContainer.appendChild(item);
    });
    
    // Attach change listener to each checkbox
    document.querySelectorAll('.image-selection-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const index = parseInt(this.dataset.index);
            images[index].selectedForSlideshow = this.checked; // Update the 'selectedForSlideshow' property in the master 'images' array
            console.log('Selection changed for image index:', index, 'Selected:', this.checked);
        });
    });

    // Set the correct speed in the dropdown within the modal
    slideshowSpeedSelect.value = slideshowSpeed.toString();
    
    selectionModal.classList.add('active'); // Show the modal
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
    console.log('openSelectionModal: Selection modal opened with all gallery images, no default selection.');
}

/**
 * Closes the slideshow selection modal.
 */
function closeSelectionModal() {
    console.log('closeSelectionModal: Closing selection modal.');
    selectionModal.classList.remove('active'); // Hide the modal
    document.body.style.overflow = 'auto'; // Restore background scrolling
    console.log('closeSelectionModal: Selection modal closed.');
}

/**
 * Starts the slideshow with the images selected in the modal.
 * This is called when the "Start Slideshow" button in the modal is clicked.
 */
function startSelectedSlideshow() {
    console.log('startSelectedSlideshow: Starting selected slideshow.');
    
    // Get the selected slideshow speed from the dropdown in the modal
    slideshowSpeed = parseInt(slideshowSpeedSelect.value);
    console.log('startSelectedSlideshow: Slideshow speed set to:', slideshowSpeed);

    // Filter the master 'images' array to get only the truly selected images for the slideshow
    slideshowImages = images.filter(img => img.selectedForSlideshow);

    if (slideshowImages.length === 0) {
        showMessageBox('Please select at least one image for the slideshow.');
        console.warn('startSelectedSlideshow: No images selected for slideshow.');
        return;
    }
    
    closeSelectionModal(); // Close the selection modal

    // Find the index of the first slideshow image within the currently filtered images
    // to ensure openLightbox displays it correctly.
    const firstSlideshowImage = slideshowImages[0];
    // We need to find the index of this image within the *currently active filter* (filteredImages)
    // because openLightbox operates on currentImageIndex which is an index into filteredImages.
    const initialLightboxIndex = filteredImages.findIndex(img => img.src === firstSlideshowImage.src);

    if (initialLightboxIndex !== -1) {
        openLightbox(firstSlideshowImage.src); // Open the first selected image
    } else {
        // This case means the first selected slideshow image is NOT in the current `filteredImages` view.
        // This can happen if the user selects images from a different category in the modal
        // and then tries to start a slideshow without changing the main gallery filter.
        // For consistency, we should ensure the lightbox shows the first selected slideshow image.
        // The simplest way is to temporarily set `filteredImages` to `slideshowImages`
        // and reset `currentImageIndex` to 0.
        console.warn("First slideshow image not in current filtered gallery. Adjusting filteredImages for slideshow.");
        filteredImages = [...slideshowImages]; // Temporarily make filteredImages the slideshow set
        currentImageIndex = 0; // Start from the first of the slideshow images
        openLightbox(filteredImages[currentImageIndex].src);
    }
    
    isSlideshowPlaying = true;
    startSlideshowInternal(); // Start the actual slideshow interval
    console.log('startSelectedSlideshow: Slideshow started with', slideshowImages.length, 'images.');
}

/**
 * Internal function to manage the setInterval for the slideshow.
 */
function startSlideshowInternal() {
    console.log('startSlideshowInternal: Initiating slideshow interval.');
    if (slideshowInterval) {
        clearInterval(slideshowInterval); // Clear any existing interval
    }
    
    // Update button text/icon for header slideshow button
    const slideshowButtonTop = slideshowButtonHeader.querySelector('.button-top');
    if (slideshowButtonTop) {
        slideshowButtonTop.innerHTML = '<i class="fas fa-pause"></i> Pause'; // Change to "Pause"
    }
    slideshowButtonHeader.title = 'Pause Slideshow';
    
    // Reset progress bar
    if (slideshowProgressBar) {
        slideshowProgressBar.style.width = '0%';
    }
    
    let progress = 0;
    const updateFrequency = 50; // Update every 50ms for smooth animation
    const increment = (updateFrequency / slideshowSpeed) * 100;
    
    slideshowInterval = setInterval(() => {
        if (slideshowProgressBar) {
            progress += increment;
            slideshowProgressBar.style.width = `${progress}%`;
        }
        
        if (progress >= 100) {
            if (slideshowProgressBar) {
                slideshowProgressBar.style.width = '0%';
            }
            progress = 0;
            
            // Advance to the next image in the `slideshowImages` array
            currentImageIndex = (currentImageIndex + 1) % slideshowImages.length;
            const nextImageInSlideshow = slideshowImages[currentImageIndex];
            
            // Open the lightbox using the image's src
            openLightbox(nextImageInSlideshow.src);
        }
    }, updateFrequency);
    console.log('startSlideshowInternal: Slideshow interval set.');
}

/**
 * Stops the slideshow.
 */
function stopSlideshow() {
    console.log('stopSlideshow: Stopping slideshow.');
    clearInterval(slideshowInterval); // Clear the interval
    slideshowInterval = null;
    isSlideshowPlaying = false; // Update flag
    
    // Update button text/icon for header slideshow button
    const slideshowButtonTop = slideshowButtonHeader.querySelector('.button-top');
    if (slideshowButtonTop) {
        slideshowButtonTop.innerHTML = '<i class="fas fa-play"></i> Slideshow'; // Change back to "Slideshow"
    }
    slideshowButtonHeader.title = 'Start Slideshow';
    
    // Reset progress bar
    if (slideshowProgressBar) {
        slideshowProgressBar.style.width = '0%';
    }

    // After stopping slideshow, revert filteredImages to the state before slideshow started
    // (e.g., based on the active filter button).
    const activeFilter = document.querySelector('.filter-btn.active');
    if (activeFilter) {
        filterImages(activeFilter.dataset.filter); // Re-apply the last active filter
        console.log('stopSlideshow: Re-applied filter:', activeFilter.dataset.filter);
    } else {
        filterImages('all'); // Default to 'all' if no filter was active
        console.log('stopSlideshow: Re-applied "all" filter.');
    }
    console.log('stopSlideshow: Slideshow stopped.');
}

/**
 * Handles the magnifier effect on the lightbox image.
 * @param {MouseEvent} e - The mouse event.
 */
function handleMagnifier(e) {
    if (!isZoomed) return; // Only apply if zoomed
    
    const img = lightboxImage;
    const imgRect = img.getBoundingClientRect(); // Get image position and size
    
    // Calculate mouse position relative to the image
    const x = e.clientX - imgRect.left;
    const y = e.clientY - imgRect.top;
    
    // Position the magnifier circle relative to the viewport
    // The CSS transform: translate(-50%, -50%) will center it on these coordinates
    magnifier.style.left = `${e.clientX}px`;
    magnifier.style.top = `${e.clientY}px`;
    
    // Set background image and size for the magnified view
    magnifier.style.backgroundImage = `url('${img.src}')`;
    magnifier.style.backgroundSize = `${imgRect.width * 2}px ${imgRect.height * 2}px`; // 2x zoom
    // Adjust background position within the magnifier to show the magnified area
    // This calculation centers the magnified portion of the image within the magnifier circle
    magnifier.style.backgroundPosition = `${-x * 2 + magnifier.offsetWidth / 2}px ${-y * 2 + magnifier.offsetHeight / 2}px`;
}

/**
 * Calculates a human-readable "time ago" string from a date string.
 * @param {string} dateString - The date string (e.g., "YYYY-MM-DD" or "1 year ago").
 * @returns {string} A human-readable time ago string.
 */
function calculateTimeAgo(dateString) {
    const now = new Date();
    const date = new Date(dateString);

    // If the date string is not a valid date, return it as is (assuming it's already "1 year ago" format)
    if (isNaN(date.getTime())) {
        return dateString;
    }

    const seconds = Math.floor((now - date) / 1000);

    let interval = seconds / 31536000; // Years
    if (interval > 1) {
        return Math.floor(interval) + (Math.floor(interval) === 1 ? " year ago" : " years ago");
    }
    interval = seconds / 2592000; // Months
    if (interval > 1) {
        return Math.floor(interval) + (Math.floor(interval) === 1 ? " month ago" : " months ago");
    }
    interval = seconds / 86400; // Days
    if (interval > 1) {
        return Math.floor(interval) + (Math.floor(interval) === 1 ? " day ago" : " days ago");
    }
    interval = seconds / 3600; // Hours
    if (interval > 1) {
        return Math.floor(interval) + (Math.floor(interval) === 1 ? " hour ago" : " hours ago");
    }
    interval = seconds / 60; // Minutes
    if (interval > 1) {
        return Math.floor(interval) + (Math.floor(interval) === 1 ? " minute ago" : " minutes ago");
    }
    return Math.floor(seconds) + (Math.floor(seconds) === 1 ? " second ago" : " seconds ago");
}


// Initialize the gallery when DOM is fully loaded
document.addEventListener('DOMContentLoaded', initGallery);